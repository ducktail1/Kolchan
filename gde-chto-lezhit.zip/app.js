(function () {
  "use strict";
  const $ = (id) => document.getElementById(id);

  // ---------- local database (IndexedDB) ----------
  const DB_NAME = "gde-chto-lezhit", DB_VER = 1;
  const STORES = ["places", "bags", "items", "photos", "meta"];
  let idb = null;
  function openDb() {
    return new Promise((res, rej) => {
      const r = indexedDB.open(DB_NAME, DB_VER);
      r.onupgradeneeded = () => {
        const d = r.result;
        STORES.forEach(s => { if (!d.objectStoreNames.contains(s)) d.createObjectStore(s, { keyPath: s === "meta" ? "key" : "id" }); });
      };
      r.onsuccess = () => res(r.result);
      r.onerror = () => rej(r.error);
    });
  }
  function tx(store, mode, fn) {
    return new Promise((res, rej) => {
      const t = idb.transaction(store, mode);
      const out = fn(t.objectStore(store));
      t.oncomplete = () => res(out && out.result !== undefined ? out.result : undefined);
      t.onerror = () => rej(t.error);
      t.onabort = () => rej(t.error);
    });
  }
  const put = (s, o) => tx(s, "readwrite", st => st.put(o));
  const del = (s, id) => tx(s, "readwrite", st => st.delete(id));
  const getAll = (s) => new Promise((res, rej) => { const r = idb.transaction(s).objectStore(s).getAll(); r.onsuccess = () => res(r.result || []); r.onerror = () => rej(r.error); });
  const getOne = (s, k) => new Promise((res, rej) => { const r = idb.transaction(s).objectStore(s).get(k); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
  function replaceAll(data) {
    return new Promise((res, rej) => {
      const t = idb.transaction(["places", "bags", "items", "photos"], "readwrite");
      ["places", "bags", "items", "photos"].forEach(s => t.objectStore(s).clear());
      (data.places || []).forEach(o => t.objectStore("places").put(o));
      (data.bags || []).forEach(o => t.objectStore("bags").put(o));
      (data.items || []).forEach(o => t.objectStore("items").put(o));
      (data.photos || []).forEach(o => t.objectStore("photos").put(o));
      t.oncomplete = res; t.onerror = () => rej(t.error); t.onabort = () => rej(t.error);
    });
  }
  const uid = (p) => p + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

  // ---------- state ----------
  let places = [], bags = [], items = [], cur = [], loaded = false;
  let mode = null, sel = new Set(), showMissing = false;
  let editing = null, photoState = null;
  const photoUrls = new Map();

  const norm = (s) => (s || "").split("/").map(x => x.trim()).filter(Boolean);
  const pathStr = (parts) => parts.join(" / ");
  const low = (s) => (s || "").toLowerCase();
  const fmt = new Intl.DateTimeFormat("ru-RU", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
  const fmtDay = new Intl.DateTimeFormat("ru-RU", { day: "numeric", month: "long", hour: "2-digit", minute: "2-digit" });
  const LOG_MAX = 80;
  const addLog = (log, e) => (Array.isArray(log) ? log : []).concat(e).slice(-LOG_MAX);
  function setStatus(msg) { const s = $("status"); s.textContent = msg || ""; s.hidden = !msg; }
  function plural(n, f) { const a = n % 10, b = n % 100; return f[(a === 1 && b !== 11) ? 0 : (a >= 2 && a <= 4 && (b < 12 || b > 14)) ? 1 : 2]; }
  const bagMap = () => Object.fromEntries(bags.map(b => [b.id, b]));
  const byOrder = (a, b) => (a.order || 0) - (b.order || 0);

  function normItem(v) {
    return { id: v.id, name: v.name || "", place: v.place || "", parts: Array.isArray(v.parts) ? v.parts : norm(v.place), in: v.in || null, qty: v.qty || "", note: v.note || "", photo: v.photo || null, missing: !!v.missing, updatedAt: v.updatedAt || 0, log: Array.isArray(v.log) ? v.log : [] };
  }
  async function saveItem(d) { const it = normItem(d); await put("items", it); const i = items.findIndex(x => x.id === it.id); if (i < 0) items.push(it); else items[i] = it; }
  async function saveBag(b) { await put("bags", b); const i = bags.findIndex(x => x.id === b.id); if (i < 0) bags.push(b); else bags[i] = b; bags.sort(byOrder); }
  async function savePlace(p) { await put("places", p); places.push(p); places.sort(byOrder); }

  function eff(it, bm) {
    const b = it.in && bm[it.in];
    if (b) return { parts: norm(b.location).concat(b.name), bag: b };
    return { parts: it.parts, bag: null };
  }
  function bagAt(parts) {
    if (!parts.length) return null;
    const name = parts[parts.length - 1], loc = pathStr(parts.slice(0, -1));
    return bags.find(b => b.name === name && pathStr(norm(b.location)) === loc) || null;
  }
  function allPlaces() {
    const s = new Set(places.map(p => p.name));
    items.forEach(it => { if (!it.in) for (let i = 1; i <= it.parts.length; i++) s.add(pathStr(it.parts.slice(0, i))); });
    const order = (p) => { const i = places.findIndex(x => x.name === norm(p)[0]); return i < 0 ? 1e6 : i; };
    return [...s].sort((a, b) => (order(a) - order(b)) || a.localeCompare(b, "ru"));
  }
  function destOptions(selEl, excludeBagId) {
    selEl.textContent = "";
    const g1 = document.createElement("optgroup"); g1.label = "В сумку";
    bags.filter(b => b.id !== excludeBagId).forEach(b => { const o = document.createElement("option"); o.value = "bag:" + b.id; o.textContent = b.name + " (" + (b.location || "?") + ")"; g1.appendChild(o); });
    const g2 = document.createElement("optgroup"); g2.label = "Положить в место";
    allPlaces().forEach(p => { const o = document.createElement("option"); o.value = "place:" + p; o.textContent = p; g2.appendChild(o); });
    if (g1.children.length) selEl.appendChild(g1);
    selEl.appendChild(g2);
  }

  // ---------- render ----------
  function render() {
    const q = low($("q").value.trim());
    const bm = bagMap();
    const all = items.map(it => ({ it, e: eff(it, bm) }));
    const viewBag = bagAt(cur);

    const cr = $("crumbs"); cr.textContent = "";
    const mk = (label, depth) => {
      const b = document.createElement("button"); b.type = "button"; b.textContent = label;
      if (depth === cur.length && !showMissing) b.setAttribute("aria-current", "true");
      b.onclick = () => { cur = cur.slice(0, depth); showMissing = false; endMode(); render(); };
      return b;
    };
    cr.appendChild(mk("Всё", 0));
    cur.forEach((p, i) => { const s = document.createElement("span"); s.className = "sep"; s.textContent = "/"; cr.appendChild(s); cr.appendChild(mk(p, i + 1)); });
    if (showMissing) { const s = document.createElement("span"); s.className = "sep"; s.textContent = "/"; cr.append(s, "не нашлись"); }

    const atRoot = !cur.length && !showMissing;
    $("bags-group").hidden = !atRoot || !loaded;
    if (atRoot) {
      const bx = $("bags"); bx.textContent = "";
      bags.forEach(b => {
        const n = items.filter(it => it.in === b.id).length;
        const btn = document.createElement("button"); btn.type = "button"; btn.className = "chip bag";
        btn.append(b.name + " ");
        const c = document.createElement("span"); c.textContent = n; btn.appendChild(c);
        const w = document.createElement("small"); w.textContent = "· " + (b.location || "место не указано"); btn.appendChild(w);
        btn.onclick = () => { cur = norm(b.location).concat(b.name); endMode(); render(); window.scrollTo(0, 0); };
        bx.appendChild(btn);
      });
      const add = document.createElement("button"); add.type = "button"; add.className = "chip link"; add.textContent = "+ сумка";
      add.onclick = () => { $("nb").hidden = false; $("nb-name").focus(); };
      bx.appendChild(add);
    }

    const inPlace = all.filter(x => cur.every((p, i) => x.e.parts[i] === p));
    const counts = new Map();
    if (!cur.length) places.forEach(p => counts.set(p.name, 0));
    inPlace.forEach(x => { const n = x.e.parts[cur.length]; if (n) counts.set(n, (counts.get(n) || 0) + 1); });
    bags.forEach(b => { if (pathStr(norm(b.location)) === pathStr(cur) && !counts.has(b.name)) counts.set(b.name, 0); });
    const ch = $("chips"); ch.textContent = "";
    const rank = (n) => { const i = places.findIndex(p => p.name === n); return cur.length || i < 0 ? 1e9 : i; };
    if (!showMissing) [...counts.entries()].sort((a, b) => (rank(a[0]) - rank(b[0])) || a[0].localeCompare(b[0], "ru")).forEach(([name, n]) => {
      const isBag = !!bagAt(cur.concat(name));
      const b = document.createElement("button"); b.type = "button"; b.className = "chip" + (isBag ? " bag" : "");
      b.append(name + " "); const c = document.createElement("span"); c.textContent = n; b.appendChild(c);
      b.onclick = () => { cur = cur.concat(name); $("q").value = ""; endMode(); render(); window.scrollTo(0, 0); };
      ch.appendChild(b);
    });
    const missingN = items.filter(it => it.missing).length;
    if (atRoot && missingN) {
      const m = document.createElement("button"); m.type = "button"; m.className = "chip miss";
      m.append("Не нашлись "); const c = document.createElement("span"); c.textContent = missingN; m.appendChild(c);
      m.onclick = () => { showMissing = true; endMode(); render(); };
      ch.appendChild(m);
    }
    if (atRoot && loaded) {
      const add = document.createElement("button"); add.type = "button"; add.className = "chip link"; add.textContent = "+ место";
      add.onclick = () => { $("np").hidden = false; $("np-name").focus(); };
      ch.appendChild(add);
    }
    $("places-h").textContent = cur.length ? "Внутри" : "Места";
    $("places-group").hidden = !ch.children.length;

    $("bag-panel").hidden = !viewBag || showMissing;
    if (viewBag) {
      const w = $("bag-where"); w.textContent = "«" + viewBag.name + "» сейчас: ";
      const bb = document.createElement("b"); bb.textContent = viewBag.location || "место не указано"; w.appendChild(bb);
    }

    let shown;
    if (showMissing) shown = all.filter(x => x.it.missing);
    else if (q) shown = all.filter(x => low(x.it.name).includes(q) || low(x.it.note).includes(q) || low(pathStr(x.e.parts)).includes(q));
    else shown = inPlace;
    shown.sort((a, b) => (b.it.updatedAt || 0) - (a.it.updatedAt || 0));

    $("count").textContent = loaded ? (items.length + " " + plural(items.length, ["вещь", "вещи", "вещей"]) + " · на этом телефоне") : "Открываю базу…";
    $("list-h").textContent = viewBag ? "В сумке" : "Вещи";
    $("pick-start").hidden = !loaded || !shown.length || !!mode;
    $("add").hidden = !loaded || !!mode;

    const list = $("list"); list.textContent = "";
    if (!shown.length) {
      const e = document.createElement("div"); e.className = "empty";
      const st = document.createElement("strong");
      if (!loaded) { st.textContent = "Открываю базу…"; e.append(st); }
      else if (q) { st.textContent = "Ничего не нашлось"; e.append(st, "Попробуй другое слово."); }
      else if (viewBag) { st.textContent = "Сумка пустая"; e.append(st, "Нажми «Добавить» или открой место и переложи вещи сюда через «Выбрать несколько»."); }
      else if (cur.length) { st.textContent = "Здесь пока пусто"; e.append(st, "Нажми «Добавить», и это место подставится само."); }
      else { st.textContent = "Здесь появятся твои вещи"; e.append(st, "Выбери место сверху и нажми «Добавить»."); }
      list.appendChild(e); return;
    }
    shown.forEach(({ it, e }) => {
      const row = document.createElement("button"); row.type = "button";
      row.className = "item" + (mode ? " pick" : "") + (mode && sel.has(it.id) ? " on" : "");
      if (mode) { const bx = document.createElement("div"); bx.className = "box"; bx.textContent = sel.has(it.id) ? "✓" : ""; row.appendChild(bx); }
      const th = document.createElement("div"); th.className = "thumb";
      const url = it.photo && photoUrls.get(it.photo);
      if (url) { const im = document.createElement("img"); im.src = url; im.alt = ""; th.appendChild(im); }
      else th.textContent = (it.name || "?")[0].toUpperCase();
      const body = document.createElement("div"); body.className = "body";
      const nm = document.createElement("div"); nm.className = "name"; nm.textContent = it.name;
      if (it.qty && it.qty !== "1") { const qn = document.createElement("span"); qn.className = "qty"; qn.textContent = " × " + it.qty; nm.appendChild(qn); }
      body.appendChild(nm);
      const tp = document.createElement("div"); tp.className = "tapes";
      if (e.bag) {
        const t1 = document.createElement("span"); t1.className = "tape bagt"; t1.textContent = e.bag.name; tp.appendChild(t1);
        const t2 = document.createElement("span"); t2.className = "tape"; t2.textContent = e.bag.location || "?"; tp.appendChild(t2);
      } else { const t = document.createElement("span"); t.className = "tape"; t.textContent = it.place || "место не указано"; tp.appendChild(t); }
      if (it.missing) { const p = document.createElement("span"); p.className = "pill"; p.textContent = "не нашёл при сверке"; tp.appendChild(p); }
      body.appendChild(tp);
      if (it.note) { const n = document.createElement("div"); n.className = "note"; n.textContent = it.note; body.appendChild(n); }
      const lastMove = (it.log || []).filter(x => x.kind === "move").slice(-1)[0];
      if (lastMove && lastMove.note) { const n = document.createElement("div"); n.className = "note"; n.textContent = "↳ " + lastMove.note; body.appendChild(n); }
      row.append(th, body);
      row.onclick = () => {
        if (mode) { sel.has(it.id) ? sel.delete(it.id) : sel.add(it.id); updateBar(); render(); }
        else openSheet(it);
      };
      list.appendChild(row);
    });
  }

  // ---------- moves ----------
  function labelFor(dest, bm) {
    if (dest.in) { const b = bm[dest.in]; return "в «" + (b ? b.name : "?") + "»" + (b && b.location ? " (" + b.location + ")" : ""); }
    return dest.place || "место не указано";
  }
  async function moveItem(it, dest, note) {
    const bm = bagMap();
    if (dest.in ? it.in === dest.in : (!it.in && it.place === dest.place)) return;
    const d = Object.assign({}, it);
    d.in = dest.in || null;
    if (!dest.in) { d.parts = norm(dest.place); d.place = pathStr(d.parts); }
    d.missing = false; d.updatedAt = Date.now();
    const e = { t: d.updatedAt, kind: "move", to: labelFor(dest, bm), in: d.in };
    if (note) e.note = note;
    d.log = addLog(it.log, e);
    await saveItem(d);
  }
  const parseDest = (v) => v.startsWith("bag:") ? { in: v.slice(4) } : { place: v.slice(6) };

  function endMode() { mode = null; sel.clear(); $("bar").hidden = true; }
  function updateBar() {
    const vb = bagAt(cur);
    $("bar-hint").textContent = mode === "check"
      ? "Отметь, что на месте: " + sel.size + " из " + items.filter(it => vb && it.in === vb.id).length + ". Неотмеченные получат пометку «не нашёл»."
      : (sel.size ? "Выбрано: " + sel.size + ". Куда переложить?" : "Отметь вещи, которые перекладываешь.");
    $("bar-go").disabled = !sel.size;
  }
  $("pick-start").onclick = () => {
    mode = "pick"; sel.clear();
    destOptions($("bar-to"), (bagAt(cur) || {}).id);
    $("bar-move").hidden = false; $("bar-note-row").hidden = false; $("bar-check").hidden = true; $("bar").hidden = false;
    updateBar(); render();
  };
  $("bar-cancel").onclick = () => { endMode(); render(); };
  $("bar-go").onclick = async () => {
    const dest = parseDest($("bar-to").value);
    const note = $("bar-note").value.trim();
    let fail = 0;
    for (const id of [...sel]) { const it = items.find(x => x.id === id); if (!it) continue; try { await moveItem(it, dest, note); } catch (e) { fail++; } }
    $("bar-note").value = ""; endMode();
    setStatus(fail ? "Не получилось переложить " + fail + " " + plural(fail, ["вещь", "вещи", "вещей"]) + "." : "");
    render();
  };
  $("bag-check").onclick = () => {
    if (!bagAt(cur)) return;
    mode = "check"; sel.clear();
    $("bar-move").hidden = true; $("bar-note-row").hidden = true; $("bar-check").hidden = false; $("bar").hidden = false;
    updateBar(); render();
  };
  $("check-cancel").onclick = () => { endMode(); render(); };
  $("check-go").onclick = async () => {
    const b = bagAt(cur); if (!b) return;
    const t = Date.now(); let miss = 0;
    for (const it of items.filter(x => x.in === b.id)) {
      const ok = sel.has(it.id); if (!ok) miss++;
      const d = Object.assign({}, it); d.missing = !ok; if (!ok) d.updatedAt = t;
      d.log = addLog(it.log, { t, kind: ok ? "check-ok" : "check-miss", to: "«" + b.name + "» (" + (b.location || "?") + ")" });
      await saveItem(d);
    }
    endMode();
    setStatus(miss ? "Сверка сохранена. Не нашлось: " + miss + ". Их история покажет, где они были в последний раз." : "Сверка сохранена, всё на месте.");
    render();
  };

  $("bag-move").onclick = () => {
    const b = bagAt(cur); if (!b) return;
    const s = $("bag-move-to"); s.textContent = "";
    allPlaces().forEach(p => { const o = document.createElement("option"); o.value = p; o.textContent = p; if (p === b.location) o.selected = true; s.appendChild(o); });
    $("bag-move-form").hidden = false; $("bag-unpack-form").hidden = true;
  };
  $("bag-move-cancel").onclick = () => { $("bag-move-form").hidden = true; };
  $("bag-move-ok").onclick = async () => {
    const b = bagAt(cur); if (!b) return;
    const to = $("bag-move-to").value; if (!to || to === b.location) { $("bag-move-form").hidden = true; return; }
    const e = { t: Date.now(), from: b.location || "", to }; const note = $("bag-move-note").value.trim(); if (note) e.note = note;
    await saveBag(Object.assign({}, b, { location: to, log: addLog(b.log, e) }));
    cur = norm(to).concat(b.name); $("bag-move-form").hidden = true; $("bag-move-note").value = ""; render();
  };
  $("bag-unpack").onclick = () => {
    const b = bagAt(cur); if (!b) return;
    $("bag-unpack-text").textContent = "Все вещи из «" + b.name + "» окажутся просто в месте «" + (b.location || "?") + "».";
    $("bag-unpack-form").hidden = false; $("bag-move-form").hidden = true;
  };
  $("bag-unpack-cancel").onclick = () => { $("bag-unpack-form").hidden = true; };
  $("bag-unpack-ok").onclick = async () => {
    const b = bagAt(cur); if (!b) return;
    for (const it of items.filter(x => x.in === b.id)) await moveItem(it, { place: b.location || "" });
    $("bag-unpack-form").hidden = true; render();
  };

  $("nb-cancel").onclick = () => { $("nb").hidden = true; $("nb-name").value = ""; };
  $("nb").addEventListener("submit", async (e) => {
    e.preventDefault();
    const name = $("nb-name").value.replace(/\//g, " ").trim();
    $("nb").hidden = true; $("nb-name").value = "";
    if (!name || bags.some(b => low(b.name) === low(name))) return;
    const order = bags.reduce((m, b) => Math.max(m, b.order || 0), 0) + 10;
    await saveBag({ id: uid("b"), name, location: places[0] ? places[0].name : "", order, log: [] });
    render();
  });
  $("np-cancel").onclick = () => { $("np").hidden = true; $("np-name").value = ""; };
  $("np").addEventListener("submit", async (e) => {
    e.preventDefault();
    const name = $("np-name").value.replace(/\//g, " ").trim();
    $("np").hidden = true; $("np-name").value = "";
    if (!name || places.some(p => low(p.name) === low(name))) return;
    const order = places.reduce((m, p) => Math.max(m, p.order || 0), 0) + 10;
    await savePlace({ id: uid("p"), name, order });
    render();
  });

  // ---------- item sheet ----------
  function fillSugg() {
    const v = norm($("f-place").value), box = $("f-sugg"); box.textContent = "";
    const kids = new Set(v.length ? [] : places.map(p => p.name));
    items.forEach(it => { if (!it.in && v.every((p, i) => it.parts[i] === p) && it.parts[v.length]) kids.add(it.parts[v.length]); });
    [...kids].sort((a, b) => v.length ? a.localeCompare(b, "ru") : 0).slice(0, 16).forEach(k => {
      const b = document.createElement("button"); b.type = "button"; b.textContent = "+ " + k;
      b.onclick = () => { $("f-place").value = pathStr(v.concat(k)); fillSugg(); };
      box.appendChild(b);
    });
  }
  function syncBagField() { $("f-place-wrap").hidden = !!$("f-bag").value; }
  function history(it) {
    const bm = bagMap(), out = [];
    const log = (it.log || []).slice().sort((a, b) => a.t - b.t);
    log.forEach((e, i) => {
      if (e.kind === "check-ok") out.push({ t: e.t, cls: "ok", text: "На месте при сверке: " + e.to });
      else if (e.kind === "check-miss") out.push({ t: e.t, cls: "miss", text: "Не нашёл при сверке: " + e.to });
      else if (e.kind === "note") out.push({ t: e.t, cls: "", text: e.note ? "Заметка: " + e.note : "Заметка снята" });
      else out.push({ t: e.t, cls: "", text: (e.in ? "Положил " : "Положил: ") + e.to + (e.note ? " — " + e.note : "") });
      if (e.kind === "move" && e.in && bm[e.in]) {
        const end = (log.slice(i + 1).find(x => x.kind === "move") || {}).t || Infinity;
        (bm[e.in].log || []).forEach(m => { if (m.t > e.t && m.t < end) out.push({ t: m.t, cls: "bagmove", text: "«" + bm[e.in].name + "» переехал: " + (m.from || "?") + " → " + m.to + (m.note ? " — " + m.note : "") }); });
      }
    });
    return out.sort((a, b) => b.t - a.t);
  }
  function openSheet(it) {
    editing = it || null;
    $("f-title").textContent = it ? "Вещь" : "Новая вещь";
    $("f-name").value = it ? it.name : "";
    const vb = bagAt(cur);
    const s = $("f-bag"); s.textContent = "";
    const o0 = document.createElement("option"); o0.value = ""; o0.textContent = "не в сумке"; s.appendChild(o0);
    bags.forEach(b => { const o = document.createElement("option"); o.value = b.id; o.textContent = b.name + " (" + (b.location || "?") + ")"; s.appendChild(o); });
    s.value = it ? (it.in || "") : (vb ? vb.id : "");
    $("f-place").value = it ? (it.in ? "" : it.place) : (vb ? "" : pathStr(cur));
    syncBagField();
    $("f-mnote").value = "";
    $("f-qty").value = it ? (it.qty || "") : "";
    $("f-note").value = it ? (it.note || "") : "";
    $("f-del").hidden = !it; $("f-confirm").hidden = true; $("f-err").hidden = true;
    photoState = { id: it && it.photo || null, file: null, cleared: false };
    showPhoto();
    const dl = $("places"); dl.textContent = "";
    allPlaces().forEach(p => { const o = document.createElement("option"); o.value = p; dl.appendChild(o); });
    fillSugg();
    const h = it ? history(it) : [];
    $("f-hist-wrap").hidden = !h.length;
    const hx = $("f-hist"); hx.textContent = "";
    h.slice(0, 40).forEach(x => { const d = document.createElement("div"); d.className = x.cls; const tm = document.createElement("time"); tm.textContent = fmt.format(new Date(x.t)); d.append(tm, x.text); hx.appendChild(d); });
    $("sheet-bg").hidden = false;
    $("form").scrollTop = 0;
  }
  function showPhoto() {
    const img = $("f-photo-img");
    if (photoState.file) { img.src = URL.createObjectURL(photoState.file); img.hidden = false; }
    else if (photoState.id && !photoState.cleared && photoUrls.get(photoState.id)) { img.src = photoUrls.get(photoState.id); img.hidden = false; }
    else img.hidden = true;
    $("f-photo-clear").hidden = img.hidden;
  }
  function closeSheet() { $("sheet-bg").hidden = true; editing = null; $("f-photo").value = ""; }
  function err(msg) { const e = $("f-err"); e.textContent = msg; e.hidden = false; }
  async function shrink(file) {
    try {
      const bmp = await createImageBitmap(file);
      const k = Math.min(1, 1280 / Math.max(bmp.width, bmp.height));
      const c = document.createElement("canvas"); c.width = Math.round(bmp.width * k); c.height = Math.round(bmp.height * k);
      c.getContext("2d").drawImage(bmp, 0, 0, c.width, c.height);
      return await new Promise(r => c.toBlob(b => r(b || file), "image/jpeg", 0.8));
    } catch (e) { return file; }
  }

  $("f-bag").addEventListener("change", syncBagField);
  $("f-place").addEventListener("input", fillSugg);
  $("f-photo").addEventListener("change", (e) => { const f = e.target.files[0]; if (f) { photoState.file = f; photoState.cleared = false; showPhoto(); } });
  $("f-photo-clear").onclick = () => { photoState.file = null; photoState.cleared = true; $("f-photo").value = ""; showPhoto(); };
  $("f-cancel").onclick = closeSheet;
  $("sheet-bg").addEventListener("click", (e) => { if (e.target === $("sheet-bg")) closeSheet(); });
  $("f-del").onclick = () => { $("f-confirm").hidden = false; };
  $("f-confirm-no").onclick = () => { $("f-confirm").hidden = true; };
  $("f-confirm-yes").onclick = async () => {
    if (!editing) return;
    const it = editing;
    await del("items", it.id);
    items = items.filter(x => x.id !== it.id);
    if (it.photo) { await del("photos", it.photo); photoUrls.delete(it.photo); }
    closeSheet(); render();
  };
  $("form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const name = $("f-name").value.trim();
    if (!name) { err("Напиши, что это за вещь."); $("f-name").focus(); return; }
    const bagId = $("f-bag").value || null;
    const parts = bagId ? [] : norm($("f-place").value);
    const btn = $("f-save"); btn.disabled = true;
    try {
      let photo = photoState.cleared ? null : photoState.id;
      const oldPhoto = photoState.id;
      if (photoState.file) {
        const blob = await shrink(photoState.file);
        photo = uid("ph");
        await put("photos", { id: photo, blob, type: blob.type || "image/jpeg" });
        photoUrls.set(photo, URL.createObjectURL(blob));
      }
      const prev = editing, t = Date.now();
      const d = { id: prev ? prev.id : uid("i"), name, place: pathStr(parts), parts, in: bagId, qty: $("f-qty").value.trim(), note: $("f-note").value.trim(), photo: photo || null, missing: prev ? !!prev.missing : false, updatedAt: t, log: prev ? (prev.log || []) : [] };
      if (prev && (prev.note || "") !== d.note) d.log = addLog(d.log, { t, kind: "note", note: d.note });
      const moved = !prev || (prev.in || null) !== bagId || (!bagId && prev.place !== d.place);
      if (moved) { d.missing = false; const le = { t, kind: "move", to: labelFor(bagId ? { in: bagId } : { place: d.place }, bagMap()), in: bagId }; const mn = $("f-mnote").value.trim(); if (mn) le.note = mn; d.log = addLog(d.log, le); }
      await saveItem(d);
      if (oldPhoto && oldPhoto !== photo) { await del("photos", oldPhoto); photoUrls.delete(oldPhoto); }
      closeSheet(); render();
    } catch (ex) {
      err(ex && ex.name === "QuotaExceededError" ? "На телефоне закончилось место для базы. Удали лишние фото." : "Не получилось сохранить. Попробуй ещё раз.");
    } finally { btn.disabled = false; }
  });

  $("q").addEventListener("input", render);
  $("add").onclick = () => openSheet(null);

  // ---------- data: export / import ----------
  function blobToDataUrl(b) { return new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(b); }); }
  async function dataUrlToBlob(u) { const r = await fetch(u); return r.blob(); }
  async function refreshDataSheet() {
    $("d-stat").innerHTML = "";
    const b = document.createElement("b"); b.textContent = items.length + " " + plural(items.length, ["вещь", "вещи", "вещей"]);
    $("d-stat").append("В базе ", b, ", " + bags.length + " " + plural(bags.length, ["сумка", "сумки", "сумок"]) + ", " + places.length + " " + plural(places.length, ["место", "места", "мест"]) + ".");
    const m = await getOne("meta", "lastExport");
    $("d-last").textContent = m ? "Последняя выгрузка: " + fmtDay.format(new Date(m.t)) + "." : "Выгрузки ещё не было.";
    let p = null;
    try { p = navigator.storage && navigator.storage.persisted ? await navigator.storage.persisted() : null; } catch (e) {}
    $("d-persist").textContent = p === true ? "Хранилище закреплено: телефон не будет чистить базу сам." : "Чтобы iOS не чистил данные, открывай приложение с иконки на экране «Домой» и делай выгрузку время от времени.";
  }
  $("data-open").onclick = async () => { $("d-msg").hidden = true; $("d-confirm").hidden = true; await refreshDataSheet(); $("data-bg").hidden = false; };
  $("d-close").onclick = () => { $("data-bg").hidden = true; };
  $("data-bg").addEventListener("click", (e) => { if (e.target === $("data-bg")) $("data-bg").hidden = true; });

  $("d-export").onclick = async () => {
    const photos = [];
    for (const p of await getAll("photos")) { try { photos.push({ id: p.id, type: p.type, data: await blobToDataUrl(p.blob) }); } catch (e) {} }
    const t = Date.now();
    const data = { app: "gde-chto-lezhit", version: 1, exportedAt: t, places, bags, items, photos };
    const d = new Date(t), pad = (n) => String(n).padStart(2, "0");
    const fname = "veshchi-" + d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()) + ".json";
    const file = new File([JSON.stringify(data)], fname, { type: "application/json" });
    let done = false;
    try {
      if (navigator.canShare && navigator.canShare({ files: [file] })) { await navigator.share({ files: [file], title: "База вещей" }); done = true; }
    } catch (e) { if (e && e.name === "AbortError") return; }
    if (!done) {
      const a = document.createElement("a"); a.href = URL.createObjectURL(file); a.download = fname;
      document.body.appendChild(a); a.click(); a.remove();
    }
    await put("meta", { key: "lastExport", t });
    await refreshDataSheet();
    const m = $("d-msg"); m.className = "ok"; m.textContent = "Файл " + fname + " готов. Сохрани его в «Файлы» или отправь в чат Claude."; m.hidden = false;
  };

  let pendingImport = null;
  $("d-import").addEventListener("change", async (e) => {
    const f = e.target.files[0]; if (!f) return;
    const m = $("d-msg"); m.hidden = true;
    try {
      const data = JSON.parse(await f.text());
      if (!data || !Array.isArray(data.items) || !Array.isArray(data.bags) || !Array.isArray(data.places)) throw new Error("bad");
      pendingImport = data;
      $("d-confirm-text").textContent = "В файле " + data.items.length + " " + plural(data.items.length, ["вещь", "вещи", "вещей"]) + ", " + data.bags.length + " " + plural(data.bags.length, ["сумка", "сумки", "сумок"]) + ", " + data.places.length + " " + plural(data.places.length, ["место", "места", "мест"]) + ". Текущая база на телефоне будет заменена.";
      $("d-confirm").hidden = false;
    } catch (ex) {
      m.className = "err"; m.textContent = "Это не файл базы вещей. Выбери .json, который выгрузило это приложение или прислал Claude."; m.hidden = false;
    }
    e.target.value = "";
  });
  $("d-confirm-no").onclick = () => { pendingImport = null; $("d-confirm").hidden = true; };
  $("d-confirm-yes").onclick = async () => {
    if (!pendingImport) return;
    const data = pendingImport; pendingImport = null;
    const photos = [];
    for (const p of data.photos || []) { try { photos.push({ id: p.id, type: p.type, blob: await dataUrlToBlob(p.data) }); } catch (e) {} }
    await replaceAll({ places: data.places, bags: data.bags, items: data.items.map(normItem), photos });
    await loadAll();
    $("d-confirm").hidden = true;
    cur = []; showMissing = false; endMode(); render();
    await refreshDataSheet();
    const m = $("d-msg"); m.className = "ok"; m.textContent = "База загружена из файла."; m.hidden = false;
  };

  // ---------- start ----------
  async function loadAll() {
    places = (await getAll("places")).sort(byOrder);
    bags = (await getAll("bags")).map(b => Object.assign({ log: [] }, b)).sort(byOrder);
    items = (await getAll("items")).map(normItem);
    photoUrls.forEach(u => URL.revokeObjectURL(u)); photoUrls.clear();
    for (const p of await getAll("photos")) if (p.blob) photoUrls.set(p.id, URL.createObjectURL(p.blob));
  }
  (async () => {
    try {
      idb = await openDb();
      const seeded = await getOne("meta", "seeded");
      if (!seeded) {
        try {
          const r = await fetch("seed.json", { cache: "no-store" });
          if (r.ok) { const data = await r.json(); await replaceAll({ places: data.places || [], bags: data.bags || [], items: (data.items || []).map(normItem), photos: [] }); }
        } catch (e) {}
        await put("meta", { key: "seeded", t: Date.now() });
      }
      await loadAll();
      loaded = true; render();
      try { if (navigator.storage && navigator.storage.persist) navigator.storage.persist(); } catch (e) {}
    } catch (e) {
      loaded = true; render();
      setStatus("Не получилось открыть базу на телефоне. Если это приватная вкладка Safari, открой обычную.");
    }
  })();
  render();

  if ("serviceWorker" in navigator) {
    window.addEventListener("load", () => { navigator.serviceWorker.register("sw.js").catch(() => {}); });
  }
})();
